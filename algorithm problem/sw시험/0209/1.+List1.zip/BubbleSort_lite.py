def BubbleSort(a):
    for i in range(len(a)-1):   # i : 0 , 1, 2, 3  pass:4
        for j in range(len(a)-1): # j : 0 1 2 3
            if a[j] > a[j+1]:
                a[j], a[j+1] = a[j+1], a[j]



arr = [55, 7, 78, 12, 42]
BubbleSort(arr)
print(arr)

